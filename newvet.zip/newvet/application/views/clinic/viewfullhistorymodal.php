<div class="modal fade" id="viewfullhistory" tabindex="-1" role="dialog" 
				 aria-labelledby="viewfullhistorylabel" aria-hidden="true">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<!-- Modal Header -->
						<div class="modal-header">
							<button type="button" class="close" 
							   data-dismiss="modal">
								   <span aria-hidden="true">&times;</span>
								   <span class="sr-only">Close</span>
							</button>
							<h4 class="modal-title" id="LabelHistory">
							   Full History
							</h4>
						</div>
		
		<!-- Modal Body -->
            <div class="modal-body">
                
				
                <table id="inventorytable" class="table">
		<tr>
			<th>Item ID</th>
			<th>Service ID</th>
			<th>Stock No.</th>
			<th>Date Used</th>
			<th>Quantity Used</th>
			<th>Total Cost</th>
			
			
		</tr>
		<tr>
			<td>401-001-001</td>
			<td>SERT-001</td>
			<td>401-001</td>
			<td>9-16-2017</td>
			<td>40</td>
			<td>Php 100.00</td>		
		</tr>
		
	</table>
                
                
            </div>            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default"
                        data-dismiss="modal">
                            Back
                </button>
                
            </div>
        </div>
    </div>
</div>


